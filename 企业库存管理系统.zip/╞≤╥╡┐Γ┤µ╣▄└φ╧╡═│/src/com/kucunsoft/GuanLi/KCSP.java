package com.kucunsoft.GuanLi;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;

import com.kucunsoft.dao.dao;
import com.kucunsoft.model.KCckinfo;
import com.kucunsoft.model.KCgysinfo;
import com.kucunsoft.model.KCkhinfo;
import com.kucunsoft.model.KCspinfo;

public class KCSP extends JFrame implements ActionListener,KeyListener{
	JButton Add,remove,xiugai,reseal;
	JLabel lab1,lab2,lab3,lab4,lab5;
	JTextField txtMsg1,txtMsg2,txtMsg3,txtMsg4;
	//���췽��
	public KCSP() {}
	
	public KCSP(String title) {
		super(title);
		this.setSize(1000, 600);
		this.setVisible(true);
		this.winInit();
	}
	public void winInit() {
		lab1=new JLabel("��Ʒ��Ϣ����");
		lab2=new JLabel("��ƷID:");
		lab3=new JLabel("��Ʒ����:");
		lab4=new JLabel("��Ʒ����:");
		lab5=new JLabel("��Ʒ�������:");
		Add=new JButton("����");
		remove=new JButton("ɾ��");
		xiugai=new JButton("�޸�");
		reseal=new JButton("����");
		txtMsg1=new JTextField(5);
		txtMsg2=new JTextField(5);
		txtMsg3=new JTextField(5);
		txtMsg4=new JTextField(5);
		Add.addActionListener(this);
		remove.addActionListener(this);
		xiugai.addActionListener(this);
		reseal.addActionListener(this);
		txtMsg1.addKeyListener(this);
		txtMsg2.addKeyListener(this);
		txtMsg3.addKeyListener(this);
		txtMsg4.addKeyListener(this);
		JPanel pNorth=new JPanel();//�������
		JPanel pSouth=new JPanel();//�Ϸ����
		JPanel scroll=new JPanel();//�������
		pNorth.add(lab1);
		pSouth.add(Add);pSouth.add(reseal);
		pSouth.add(remove);pSouth.add(xiugai);
		scroll.add(lab2);scroll.add(txtMsg1);
		scroll.add(lab3);scroll.add(txtMsg2);
		scroll.add(lab4);scroll.add(txtMsg3);
		scroll.add(lab5);scroll.add(txtMsg4);
		scroll.setLayout(new GridLayout(10,2,5,20));
		//���봰��
		add(pNorth,"North");
		add(pSouth,"South");
		add(scroll,"Center");
		
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
			}
		});
	}
	//�¼�����
	public void actionPerformed(ActionEvent e) {
		dao da=new dao();
		if(e.getActionCommand().equals("����")){
			KCspinfo sp = new KCspinfo();
			sp.setId(Integer.parseInt(txtMsg1.getText()));                   //id
			sp.setName(txtMsg2.getText());                                   //name
			sp.setJj(Double.parseDouble(txtMsg3.getText()));                 //jinjia
			sp.setnum(Integer.parseInt(txtMsg4.getText()));                  //shuliang
			da.insertshangpin(sp);
		}else if(e.getActionCommand().equals("ɾ��")) {
			KCspinfo sp=new KCspinfo();
			//System.out.println(txtMsg1.getText());
			sp.setId(Integer.parseInt(txtMsg1.getText()));
			da.deleteshangpin(sp);
		}else if(e.getActionCommand().equals("�޸�")) {
			KCspinfo sp = new KCspinfo();
			sp.setId(Integer.parseInt(txtMsg1.getText()));                   //id
			sp.setName(txtMsg2.getText());                                   //name
			sp.setJj(Double.parseDouble(txtMsg3.getText()));                 //jinjia
			sp.setnum(Integer.parseInt(txtMsg4.getText()));                  //shuliang	 
			da.updatesp(sp);
		}else if(e.getActionCommand().equals("����")) {
			txtMsg1.setText("");
			txtMsg2.setText("");
			txtMsg3.setText("");
			txtMsg4.setText("");
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO �Զ����ɵķ������
		
	}
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO �Զ����ɵķ������
		
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO �Զ����ɵķ������
		
	}
}