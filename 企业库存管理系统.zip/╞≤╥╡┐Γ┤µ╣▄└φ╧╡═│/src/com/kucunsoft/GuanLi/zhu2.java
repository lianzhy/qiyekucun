package com.kucunsoft.GuanLi;

import java.awt.Button;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.*;
import com.kucunsoft.GuanLi.*;

public class zhu2 extends JFrame implements ActionListener,KeyListener{
	JButton comm,out,in,supp,ware,cust;
	JLabel lab1;
	//���췽��
	public zhu2() {
		super("��Ϣ��ѯ");
		//this.setSize(1000, 600);
		this.winInit();
	}
	public void winInit() {
		//lab1=new JLabel("��Ϣ��ѯ");
		comm=new JButton("��ѯ��Ʒ��Ϣ");
		out=new JButton("��ѯ������Ϣ");
		in=new JButton("��ѯ�����Ϣ");
		supp=new JButton("��ѯ��Ӧ����Ϣ");
		ware=new JButton("��ѯ�ֿ���Ϣ");
		cust=new JButton("��ѯ�ͻ���Ϣ");
		this.setLayout(new GridLayout(2,3));//2��3��
		this.add(comm);
		this.add(out);
		this.add(in);
		this.add(supp);
		this.add(ware);
		this.add(cust);
		comm.addActionListener(this);
		out.addActionListener(this);
		in.addActionListener(this);
		supp.addActionListener(this);
		ware.addActionListener(this);
		cust.addActionListener(this);
		this.setBounds(200,100,450,350);
		this.setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getActionCommand().equals("��ѯ�ͻ���Ϣ")) {
			Cust kh = new Cust();
			kh.setVisible(true);
		}
		else if(e.getActionCommand().equals("��ѯ������Ϣ")) {
			Out out = new Out();
			out.setVisible(true);
		}
		else if(e.getActionCommand().equals("��ѯ�����Ϣ")) {
			In in = new In();
			in.setVisible(true);
		}
		else if(e.getActionCommand().equals("��ѯ��Ӧ����Ϣ")) {
			Supp gys = new Supp();
			gys.setVisible(true);
		}
		else if(e.getActionCommand().equals("��ѯ�ֿ���Ϣ")) {
			Ware ck = new Ware();
			ck.setVisible(true);
		}
		else if(e.getActionCommand().equals("��ѯ��Ʒ��Ϣ")) {
			Comm sp= new Comm();
			sp.setVisible(true);
			}
		}
	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
}
