package com.kucunsoft.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import com.kucunsoft.model.*;

public class dao {
	protected static String dbClassName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	protected static String dbUrl = "jdbc:mysql://localhost:3306/企业库存管理db?serverTimezone=UTC";
	protected static String dbUser = "root";
	protected static String dbPwd = "158437";
	protected static String second = null;
	static Connection conn = null;
	static Statement sm = null;
	static ResultSet rs = null;

	public dao() {	
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("成功加载Mysql驱动");
		}
		catch(Exception e) {
			System.out.println("加载Mysql失败");
			e.printStackTrace();
		}
		try {
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/企业库存管理db?serverTimezone=UTC","root","158437" );
			conn = connect;
			System.out.println("成功连接Mysql数据库");
		}
		catch(Exception e) {
			System.out.print("连接数据库失败");
			e.printStackTrace();
		}
	}
	
	//增加客户
	public static void insertkehu(KCkhinfo kh) {
		boolean result;
		try {
			if(conn==null)
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/企业库存管理db?serverTimezone=UTC","root","158437" );
			//创建Statement或者PreparedStatement
			//Statement用处是：发送sql语句到数据库
			sm = conn.createStatement();
			//添加数据
			String sql = "insert into cust_info values("+kh.getId()+","+kh.getTel()+",'"+kh.getName()+"', '"+kh.getSex()+"')";	
			result = sm.execute(sql);
			if(!result) {
				System.out.println("增加客户成功！");
			}else
				System.out.println("增加客户失败！");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//修改客户信息
	public static void updatekehu(KCkhinfo kh) {
		boolean result;
		try {
			if(conn==null)
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/企业库存管理db?serverTimezone=UTC","root","158437" );
			//创建Statement或者PreparedStatement
			//Statement用处是：发送sql语句到数据库
			sm = conn.createStatement();
			//添加数据
			String sql = "update cust_info set Cpho_num="+kh.getTel()+",Cnam='"+kh.getName()+"',Csex='"+kh.getSex()+"' where Cust_ID="+kh.getId()+";";	
			result = sm.execute(sql);
			if(!result) {
				System.out.println("修改客户成功！");
			}else
				System.out.println("修改客户失败！");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//删除客户
	public static void deletekehu(KCkhinfo kh) {
		boolean result;
		try {
			if(conn==null)
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/企业库存管理db?serverTimezone=UTC","root","158437" );
			//创建Statement或者PreparedStatement
			//Statement用处是：发送sql语句到数据库
			sm = conn.createStatement();
			//添加数据
			String sql = "delete from cust_info where Cust_ID="+kh.getId()+";";	
			result = sm.execute(sql);
			if(!result) {
				System.out.println("删除客户成功！");
			}else
				System.out.println("删除客户失败！");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//增加供应商
	public static void insertgongyingshang(KCgysinfo gys) {
		boolean result=false;
		try {
			if(conn==null)
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/企业库存管理db?serverTimezone=UTC","root","158437" );
			//创建Statement或者PreparedStatement
			//Statement用处是：发送sql语句到数据库
			sm = conn.createStatement();
			//添加数据
			String sql = "insert into supp_info values("+gys.getId()+","+gys.getTel()+",'"+gys.getName()+"', '"+gys.getSex()+"')";	
			result=sm.execute(sql);
			if(!result) {
				System.out.println("增加供应商成功！");
			}else
				System.out.println("增加供应商失败！");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//修改供应商
	public static void updategys(KCgysinfo gys) {
		boolean result;
		try {
			if(conn==null)
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/企业库存管理db?serverTimezone=UTC","root","158437" );
			//创建Statement或者PreparedStatement
			//Statement用处是：发送sql语句到数据库
			sm = conn.createStatement();
			//添加数据
			String sql = "update supp_info set Spho_num="+gys.getTel()+",Snam='"+
			gys.getName()+"',Ssex='"+gys.getSex()+"' where Supp_ID="+gys.getId()+";";	
			result = sm.execute(sql);
			if(!result) {
				System.out.println("修改供应商成功！");
			}else
				System.out.println("修改供应商失败！");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//删除供应商
	public static void deletegongyingshang(KCgysinfo gys) {
		boolean result;
		try {
			if(conn==null)
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/企业库存管理db?serverTimezone=UTC","root","158437" );
			//创建Statement或者PreparedStatement
			//Statement用处是：发送sql语句到数据库
			sm = conn.createStatement();
			//添加数据
			String sql = "delete from supp_info where Supp_ID="+gys.getId()+";";	
			result = sm.execute(sql);
			if(!result) {
				System.out.println("删除供应商成功！");
			}else
				System.out.println("删除供应商失败！");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//添加商品
	public static void insertshangpin(KCspinfo sp) {
		boolean result=false;
		try {
			if(conn==null)
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/企业库存管理db?serverTimezone=UTC","root","158437" );
			//创建Statement或者PreparedStatement
			//Statement用处是：发送sql语句到数据库
			sm = conn.createStatement();
			//添加数据
			String sql = "insert into comm_info values("+sp.getId()+",'"+sp.getName()+"',"+sp.getJj()+", "+sp.getnum()+");";	
			result=sm.execute(sql);
			if(!result) {
				System.out.println("增加商品成功！");
			}else
				System.out.println("增加商品失败！");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//修改商品
	public static void updatesp(KCspinfo sp) {
		boolean result;
		try {
			if(conn==null)
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/企业库存管理db?serverTimezone=UTC","root","158437" );
			//创建Statement或者PreparedStatement
			//Statement用处是：发送sql语句到数据库
			sm = conn.createStatement();
			//添加数据
			String sql = "update comm_info set Comm_name='"+sp.getName()+"',Comm_inpr="+
			sp.getJj()+",Comm_num="+sp.getnum()+" where Comm_ID="+sp.getId()+";";	
			result = sm.execute(sql);
			if(!result) {
				System.out.println("修改商品成功！");
			}else
				System.out.println("修改商品失败！");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	//删除商品
	public static void deleteshangpin(KCspinfo sp) {
		boolean result;
		try {
			if(conn==null)
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/企业库存管理db?serverTimezone=UTC","root","158437" );
			//创建Statement或者PreparedStatement
			//Statement用处是：发送sql语句到数据库
			sm = conn.createStatement();
			//添加数据
			String sql = "delete from comm_info where Comm_ID="+sp.getId()+";";	
			result = sm.execute(sql);
			if(!result) {
				System.out.println("删除商品成功！");
			}else
				System.out.println("删除商品失败！");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//添加管理员
	public static void insertguanliyuan(KCglyinfo gly) {
		boolean result=false;
		try {
			if(conn==null)
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/企业库存管理db?serverTimezone=UTC","root","158437" );
			//创建Statement或者PreparedStatement
			//Statement用处是：发送sql语句到数据库
			sm = conn.createStatement();
			//添加数据
			String sql = "insert into admi_info values("+gly.getId()+",'"+gly.getName()+"','"+gly.getSex()+"');";	
			result=sm.execute(sql);
			if(!result) {
				System.out.println("增加管理员成功！");
			}else
				System.out.println("增加管理员失败！");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//修改管理员
	public static void updategly(KCglyinfo gly) {
		boolean result;
		try {
			if(conn==null)
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/企业库存管理db?serverTimezone=UTC","root","158437" );
			//创建Statement或者PreparedStatement
			//Statement用处是：发送sql语句到数据库
			sm = conn.createStatement();
			//添加数据
				
			String sql = "update admi_info set Anam='"+
			gly.getName()+"',Asex='"+gly.getSex()+"' where Admi_ID="+gly.getId()+";";
			result = sm.execute(sql);
			if(!result) {
				System.out.println("修改管理员成功！");
			}else
				System.out.println("修改管理员失败！");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//删除管理员
	public static void deleteguanliyuan(KCglyinfo gly) {
		boolean result;
		try {
			if(conn==null)
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/企业库存管理db?serverTimezone=UTC","root","158437" );
			//创建Statement或者PreparedStatement
			//Statement用处是：发送sql语句到数据库
			sm = conn.createStatement();
			//添加数据
			String sql = "delete from admi_info where Admi_ID="+gly.getId()+";";	
			result = sm.execute(sql);
			if(!result) {
				System.out.println("删除管理员成功！");
			}else
				System.out.println("删除管理员失败！");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//添加仓库
	public static void insertcangku(KCckinfo ck) {
		boolean result=false;
		try {
			if(conn==null)
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/企业库存管理db?serverTimezone=UTC","root","158437" );
			//创建Statement或者PreparedStatement
			//Statement用处是：发送sql语句到数据库
			sm = conn.createStatement();
			//添加数据
			String sql = "insert into ware_info values("+ck.getId()+",'"+ck.getName()+"',"+ck.getNO()+");";	
			result=sm.execute(sql);
			if(!result) {
				System.out.println("增加仓库成功！");
			}else
				System.out.println("增加仓库失败！");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//修改仓库
	public static void updateck(KCckinfo ck) {
		boolean result;
		try {
			if(conn==null)
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/企业库存管理db?serverTimezone=UTC","root","158437" );
			//创建Statement或者PreparedStatement
			//Statement用处是：发送sql语句到数据库
			sm = conn.createStatement();
			//添加数据
			String sql = "update ware_info set Ware_addr='"+ck.getName()+"',Ware_cout='"+
			ck.getNO()+"' where Ware_ID="+ck.getId()+";";	
			result = sm.execute(sql);
			if(!result) {
				System.out.println("修改仓库成功！");
			}else
				System.out.println("修改仓库失败！");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//删除仓库
	public static void deletecangku(KCckinfo ck) {
		boolean result;
		try {
			if(conn==null)
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/企业库存管理db?serverTimezone=UTC","root","158437" );
			//创建Statement或者PreparedStatement
			//Statement用处是：发送sql语句到数据库
			sm = conn.createStatement();
			//添加数据
			String sql = "delete from ware_info where Ware_ID="+ck.getId()+";";	
			result = sm.execute(sql);
			if(!result) {
				System.out.println("删除仓库成功！");
			}else
				System.out.println("删除仓库失败！");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
}
	//查询商品信息
