package com.kucunsoft.model;

public class KCgysinfo {

			//��Ӧ����Ϣ
			private int gysid;
			private String gysname;
			private String gyssex;
			private long gystel;
			
			//���췽��
			public KCgysinfo() {}
			
			public KCgysinfo(int gysid) {
				this.gysid = gysid;
			}
			
			public KCgysinfo(int gysid,String gysname,String gyssex,long gystel) {
				this.gysid = gysid;
				this.gysname = gysname;
				this.gyssex = gyssex;
				this.gystel = gystel;
			}
			
			//
			public int getId() {
				return this.gysid;
			}
			
			public void setId(int gysid) {
				this.gysid = gysid;
			}
			
			public String getName() {
				return this.gysname;
			}
			
			public void setName(String gysname) {
				this.gysname = gysname;
			}
			
			public String getSex() {
				return this.gyssex;
			}
			
			public void setSex(String gyssex) {
				this.gyssex = gyssex;
			}
			
			public long getTel() {
				return this.gystel;
			}
			
			public void setTel(long gystel) {
				this.gystel = gystel;
			}
}
