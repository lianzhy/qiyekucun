package com.kucunsoft.model;

public class KCkhinfo {
		
		//�ͻ���Ϣ
		private int khid;
		private String khname;
		private String khsex;
		private long khtel;
		
		//���췽��
		public KCkhinfo() {}
		
		public KCkhinfo(int khid) {
			this.khid = khid;
		}
		
		public KCkhinfo(int khid,String khname,String khsex,long khtel) {
			this.khid = khid;
			this.khname = khname;
			this.khsex = khsex;
			this.khtel = khtel;
		}
		
		//
		public int getId() {
			return this.khid;
		}
		
		public void setId(int khid) {
			this.khid = khid;
		}
		
		public String getName() {
			return this.khname;
		}
		
		public void setName(String khname) {
			this.khname = khname;
		}
		
		public String getSex() {
			return this.khsex;
		}
		
		public void setSex(String khsex) {
			this.khsex = khsex;
		}
		
		public long getTel() {
			return this.khtel;
		}
		
		public void setTel(long khtel) {
			this.khtel = khtel;
		}
}
