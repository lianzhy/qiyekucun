package com.kucunsoft.model;

public class KCsprk {

	//��Ʒ���
	private int gl1id;
	private int spid;
	private int rkid;
	
	//���췽��
	public int getGl1Id() {
		return this.gl1id;
	}
	
	public void setGl1Id(int gl1id) {
		this.gl1id = gl1id;
	}
	
	public int getSpId() {
		return this.spid;
	}
	
	public void setSpId(int spid) {
		this.spid = spid;
	}
	
	public int getRkId() {
		return this.rkid;
	}
	
	public void setRkId(int rkid) {
		this.rkid = rkid;
	}
}
