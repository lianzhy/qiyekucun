package com.kucunsoft.model;

import java.util.Date;

public class KCrkinfo {

	//�����Ϣ
	private int rkid;
	private int ckid;
	private Date rktime;
	private int glyid;
	private int gysid;
	
	//���췽��
	public KCrkinfo() {}
	
	public KCrkinfo(int rkid) {
		this.rkid = rkid;
	}
	
	public KCrkinfo(int rkid,int ckid,Date rktime,int glyid,int gysid) {
		this.rkid = rkid;
		this.ckid = ckid;
		this.rktime = rktime;
		this.glyid = glyid;
		this.gysid = gysid;
	}
	
	//
	public int getRkId() {
		return this.rkid;
	}
	
	public void setRkId(int rkid) {
		this.rkid = rkid;
	}
	
	public int getCkId() {
		return this.ckid;
	}
	
	public void setCkId(int ckid) {
		this.ckid = ckid;
	}
	
	public Date getRkTime() {
		return this.rktime;
	}
	
	public void setRkTime(Date rktime) {
		this.rktime = rktime;
	}
	
	public int getGlyId() {
		return this.glyid;
	}
	
	public void setGlyId(int glyid) {
		this.glyid = glyid;
	}
	
	public int getGysId() {
		return this.gysid;
	}
	
	public void setGysId(int gysid) {
		this.gysid = gysid;
	}
	
}
