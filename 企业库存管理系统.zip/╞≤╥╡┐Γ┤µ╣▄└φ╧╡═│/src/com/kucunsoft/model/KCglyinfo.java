package com.kucunsoft.model;

public class KCglyinfo{
	
	//����Ա��Ϣ
	private int glyid;
	private String glyname;
	private String glysex;
	
	//���췽��
	public KCglyinfo() {}
	
	//�޸�id
	public KCglyinfo(int glyid) {
		this.glyid = glyid;
	}
	
	//�޸�ȫ������
	public KCglyinfo(int glyid,String glyname,String glysex) {
		this.glyid = glyid;
		this.glyname = glyname;
		this.glysex = glysex;
	}
	
	//
	public int getId() {
		return this.glyid;
	}
	
	public void setId(int glyid) {
		this.glyid = glyid;
	}
	
	public String getName() {
		return this.glyname;
	}
	
	public void setName(String glyname) {
		this.glyname = glyname;
	}
	
	public String getSex() {
		return this.glysex;
	}
	
	public void setSex(String glysex) {
		this.glysex = glysex;
	}
	
}
