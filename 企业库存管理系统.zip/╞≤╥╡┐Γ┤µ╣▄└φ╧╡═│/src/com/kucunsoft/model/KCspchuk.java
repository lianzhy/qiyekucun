package com.kucunsoft.model;

public class KCspchuk {
	//��Ʒ����
	private int gl4id;
	private int spid;
	private int chukid;
	
	//���췽��
	public int getGl4Id() {
		return this.gl4id;
	}
	
	public void setGl4Id(int gl4id) {
		this.gl4id = gl4id;
	}
	
	public int getSpId() {
		return this.spid;
	}
	
	public void setSpId(int spid) {
		this.spid = spid;
	}
	
	public int getChukId() {
		return this.chukid;
	}
	
	public void setChukId(int chukid) {
		this.chukid = chukid;
	}
}
