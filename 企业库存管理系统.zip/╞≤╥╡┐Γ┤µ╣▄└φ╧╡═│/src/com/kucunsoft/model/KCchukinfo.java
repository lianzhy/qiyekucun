package com.kucunsoft.model;

import java.util.Date;

public class KCchukinfo {
	//�����Ϣ
		private int chukid;
		private int chuknum;
		private int ckid;
		private Date chuktime;
		private int glyid;
		private int spid;
		private int khid;
		
		//���췽��
		public KCchukinfo() {}
		
		public KCchukinfo(int chukid) {
			this.chukid = chukid;
		}
		
		public KCchukinfo(int chukid,int chuknum,int ckid,Date chuktime,int glyid,int spid,int khid) {
			this.chukid = chukid;
			this.chuknum = chuknum;
			this.ckid = ckid;
			this.chuktime = chuktime;
			this.glyid = glyid;
			this.spid = spid;
			this.khid = khid;
		}
		
		//
		public int getChukId() {
			return this.chukid;
		}
		
		public void setChukId(int chukid) {
			this.chukid = chukid;
		}
		
		public	int getChukNum() {
			return this.chuknum;
		}
		
		public void setChukNum(int chuknum) {
			this.chuknum = chuknum;
		}
		
		public int getCkId() {
			return this.ckid;
		}
		
		public void setCkId(int ckid) {
			this.ckid = ckid;
		}
		
		public Date getChukTime() {
			return this.chuktime;
		}
		
		public void setchukTime(Date chuktime) {
			this.chuktime = chuktime;
		}
		
		public int getGlyId() {
			return this.glyid;
		}
		
		public void setGlyId(int glyid) {
			this.glyid = glyid;
		}
		
		public int getSpId() {
			return this.spid;
		}
		
		public void setSpId(int spid) {
			this.spid = spid;
		}
		
		public int  getKhId() {
			return this.khid;
		}
		
		public void setKhId(int khid) {
			this.khid = khid;
		}
}
