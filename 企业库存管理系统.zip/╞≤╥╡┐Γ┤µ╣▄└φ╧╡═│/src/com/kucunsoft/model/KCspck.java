package com.kucunsoft.model;

public class KCspck {
	//��Ʒ�ֿ�
	private int gl3id;
	private int spid;
	private int ckid;
	
	//���췽��
	public int getGl3Id() {
		return this.gl3id;
	}
	
	public void setGl3Id(int gl3id) {
		this.gl3id = gl3id;
	}
	
	public int getSpId() {
		return this.spid;
	}
	
	public void setSpId(int spid) {
		this.spid = spid;
	}
	
	public int getCkId() {
		return this.ckid;
	}
	
	public void setCkId(int ckid) {
		this.ckid = ckid;
	}
}
