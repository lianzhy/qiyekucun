package com.kucunsoft.model;

public class KCspinfo {

	//��Ʒ��Ϣ
	private int spid;
	private String spname;
	private double spjj;
	private int spnum;
	
	//���췽��
	public KCspinfo() {}
	
	public KCspinfo(int spid) {
		this.spid = spid;
	}
	
	public KCspinfo(int spid,String spname,double spjj,int spnum) {
		this.spid = spid;
		this.spname = spname;
		this.spjj = spjj;
		this.spnum = spnum;
	}
	
	//
	public int getId() {
		return this.spid;
	}
	
	public void setId(int spid) {
		this.spid = spid;
	}
	
	public String getName() {
		return this.spname;
	}
	
	public void setName(String spname) {
		this.spname = spname;
	}
	
	public double getJj() {
		return this.spjj;
	}
	
	public void setJj(double spjj) {
		this.spjj = spjj;
	}
	
	public int getnum() {
		return this.spnum;
	}
	
	public void setnum(int spnum) {
		this.spnum = spnum;
	}
}
