package com.kucunsoft.model;

public class KCckinfo {
	
	//�ֿ���Ϣ
	private int ckid;
	private String ckaddr;
	private int ckNO;
	
	//���췽��
	public KCckinfo() {}
	
	public KCckinfo(int ckid) {
		this.ckid = ckid;
	}
	
	public KCckinfo(int ckid,String ckaddr,int ckNO) {
		this.ckid = ckid;
		this.ckaddr = ckaddr;
		this.ckNO = ckNO;
	}
	
	//
	public int getId() {
		return this.ckid;
	}
	
	public void setId(int ckid) {
		this.ckid = ckid;
	}
	
	public String getName() {
		return this.ckaddr;
	}
	
	public void setName(String ckaddr) {
		this.ckaddr = ckaddr;
	}
	
	public int getNO() {
		return this.ckNO;
	}
	
	public void setNO(int ckNO) {
		this.ckNO = ckNO;
	}
}
