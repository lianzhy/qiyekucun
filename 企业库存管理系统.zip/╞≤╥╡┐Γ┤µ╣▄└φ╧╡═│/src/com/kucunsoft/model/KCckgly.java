package com.kucunsoft.model;

public class KCckgly {
	//�ֿ����Ա
	private int gl2id;
	private int glyid;
	private int ckid;
	
	//���췽��
	public int getGl2Id() {
		return this.gl2id;
	}
	
	public void setGl2Id(int gl2id) {
		this.gl2id = gl2id;
	}
	
	public int getGlyId() {
		return this.glyid;
	}
	
	public void setGlyId(int glyid) {
		this.glyid = glyid;
	}
	
	public int getCkId() {
		return this.ckid;
	}
	
	public void setCkId(int ckid) {
		this.ckid = ckid;
	}
}
